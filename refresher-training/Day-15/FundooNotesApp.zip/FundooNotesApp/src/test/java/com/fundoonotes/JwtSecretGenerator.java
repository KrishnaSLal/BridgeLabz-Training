package com.fundoonotes;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Encoders;

import javax.crypto.SecretKey;

public class JwtSecretGenerator {

    public static void main(String[] args) {

        SecretKey key = Jwts.SIG.HS256.key().build();

        String secret =
                Encoders.BASE64.encode(key.getEncoded());

        System.out.println("JWT_SECRET=");
        System.out.println(secret);
    }
}